package com.example.farfromhome

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
